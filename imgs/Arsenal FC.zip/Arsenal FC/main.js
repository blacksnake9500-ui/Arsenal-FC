const header = document.querySelector("header");
const headerImages = ["imgs/Arsenal logo.png", "imgs/bg2.png"];
let currentHeaderIndex = 0;

function changeHeaderBackground() {
  if (!header) return;
  header.style.backgroundImage = `url('${headerImages[currentHeaderIndex]}')`;
  currentHeaderIndex = (currentHeaderIndex + 1) % headerImages.length;
}

changeHeaderBackground();
setInterval(changeHeaderBackground, 5000);
